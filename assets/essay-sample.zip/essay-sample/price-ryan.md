---
title: The Art of Crowdsourcing
lname: Price
fname: Ryan
email: ryan.price@ryerson.ca
web: ryerson.ryanprice.net
license: BY-SA
image-description: Running Jaguars from the Library of Congress Flickr pool
bio: Ryan is an educator at Ryerson University. He is interested in art, design, and technology and how all of those things fit together.
---

The United States Library of Congress uploaded over one million historical images to the digital Commons via Flickr with no copyright assigned to any of the images. The idea behind the gift of high resolution, high quality historical photos was that in exchange for the unsorted photos, Flickr users would eventually organize and tag all of the images, providing metadata for the content that would otherwise take years of government funding if the Library of Congress hired a staffer for the task.

Similarly, Google's reCaptcha system asks users to enter a piece of garbled text or blurred set of numbers into a text box in order to prove their humanness to the computer. In actuality, this test of being human is a coordinated effort by Google to get consensus on what the text is after a computer has failed to decipher it by way of it's optical character recognition tests. reCaptca captures over 150,000 hours of labour a day from the brief seconds of effort exhausted by Web users as they try to login to their respective networks while proving they are in fact human.

This is plain old paragraph text. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.  

**Bold text**

_italicized text_

1. A numbered
2. List in case
3. You need one

- Bullet
- Lists,
- Too

[Link text](http://www.ryerson.ca)