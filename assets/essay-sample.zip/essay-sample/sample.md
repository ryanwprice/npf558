---
title: 
lname: 
fname: 
email: 
web: 
license: 
image-description: 
bio: 
---

Here are some instructions: In the section above you need to fill in the blanks. There is an example on the assignments page of the website. The title is the title of your essay. lname is your Last Name. fname is your First Name. email is for an email address you wish to be contacted at; leave this blank if you wish. Ditto for web, it is a website to promote yourself. license is the Creative Commons license. You can apply any license you wish. If you leave it blank, full copyright will be applied. image-description is a short (50 words or less) description of the accompanying image for the essay. The bio is a brief author bio for the the publication.

All of this text is written in markdown. It may seem scary, but its pretty much just typing. There are lots of resources on the assignment page of the class site to help you.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
