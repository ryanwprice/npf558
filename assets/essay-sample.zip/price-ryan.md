---
title: The Art of Crowdsourcing
lname: Price
fname: Ryan
email: ryan.price@ryerson.ca
web: ryerson.ryanprice.net
license: BY-SA
image-description: Running Jaguars from the Library of Congress Flickr pool
bio: Ryan is an educator at Ryerson University. He is interested in art, design, and technology and how all of those things fit together.
---

The United States Library of Congress uploaded over one million historical images to the digital Commons via Flickr with no copyright assigned to any of the images. The idea behind the gift of high resolution, high quality historical photos was that in exchange for the unsorted photos, Flickr users would eventually organize and tag all of the images, providing metadata for the content that would otherwise take years of government funding if the Library of Congress hired a staffer for the task.

Similarly, Google's reCaptcha system asks users to enter a piece of garbled text or blurred set of numbers into a text box in order to prove their humanness to the computer. In actuality, this test of being human is a coordinated effort by Google to get consensus on what the text is after a computer has failed to decipher it by way of it's optical character recognition tests. reCaptca captures over 150,000 hours of labour a day from the brief seconds of effort exhausted by Web users as they try to login to their respective networks while proving they are in fact human.

The collating efforts given to the Library of Congress and the login attempts via reCaptcha are both examples of _crowdsourcing_, a term coined by Jeff Howe in the article "The Rise of Crowdsourcing" from _Wired_ magazine back in June 2006. Crowdsourcing is, essentially, when "companies operate by broadcasting problems or challenges to the crowd. Individuals in the crowd offer solutions to these problems and post the solution back to the online commons" (Brabhamb 1124). Crowdsourcing takes advantage of the technology of the Internet,  providing "unprecedented levels of collaboration and meaningful exchanges between people from every imaginable background in every imaginable geographic location" (Howe 14). Crowdsourcing takes advantage of people's creative energies, which is as "endlessly inventive as it is infinitely renewable (Howe 177). It affords the opportunity to be creative to everyone, professional or amateur, regardless of geographic location, age, race, or gender; as the infamous New Yorker cartoon suggests, "on the Internet, nobody knows you're a dog". Crowdsourcing is "design by democracy" (Howe 2).